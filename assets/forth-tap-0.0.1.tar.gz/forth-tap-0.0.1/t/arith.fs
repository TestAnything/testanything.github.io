#! /usr/local/bin/gforth

require ../lib/test-more.fs

2 plan
1 1 + 2 = ok
2 1 - 1 = ok

bye
